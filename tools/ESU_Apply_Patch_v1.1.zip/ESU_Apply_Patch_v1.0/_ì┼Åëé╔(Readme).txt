# Server 2008 Update Patcher

* このツールは、Windows Server 2008 の更新を受け取れるようにします。

______________________________

## 必須要件

* 以下の言語をサポートしています。

cs-CZ / Czech  
de-DE / German  
en-US / 英語
es-ES / スペイン語
fr-FR / フランス語
hu-HU / ハンガリー語 
it-IT / イタリア語
ja-JP / 日本語
ko-KR / 韓国語
nl-NL / ドイツ語
pl-PL / ポーランド語 
pt-BR / ブラジル語
pt-PT / ポルトガル語 
ru-RU / ロシア語
sv-SE / スウェーデン語
tr-TR / トルコ語
zh-CN / 	簡体字、中国
zh-HK / 	繁体字、香港特別行政区
zh-TW / 	繁体字、台湾

* このパッチを実行する前に、VistaUpdaterを実行する必要があります。

* "Windows Management Instrumentation (winmgmt)" サービスが有効になっていることを確認します。
* 管理者権限が有効になっているアカウントで実行することを推奨します。

______________________________

##使い方

* VistaUpdaterを実行します。

* Zip ファイルを好きなフォルダに展開します。(例: C:\Users\Administrator\Downloads\ESU_Apply_Patch_v*.*)

* ウイルス対策ソフトが有効になっている場合、無効にします。

* Server2008Patcher.cmd を管理者権限で実行します。

メニューから、どれをパッチするかを選択します。

[1] Windows Vista の更新を受け取る
Microsoft 公式の更新を受け取ります。

[2] Server 2008 の更新を受け取る
Windows Server 2008 の更新を受け取ります。
ESUの更新をインストールする場合は、"ESUApplyPatch.cmd" を実行します。

[3] Server 2008 と Vista の更新を受け取る（推奨）
Windows Vista の更新と Server 2008 の更新を両方受け取ります。
すでにインストールされている更新プログラムを受け取る可能性があります。
ESUの更新をインストールする場合は、"ESUApplyPatch.cmd" を実行します。

______________________________

##注意事項

* ESUのアップデートを受け取るには、"ESUApplyPatch.cmd" を管理者として実行します。

* いつでも、オプションを変更することができます。
再起動が必要です。更新プログラムを再度確認する必要があります。

* このツールは、古いOSを使い続けることを推奨しているわけではなく、エンターテイメントや古いソフトウェアを実行する方向けに作られました。

* このツール及びVistaUpdaterは、Microsoftによって連携、承認されていません。

* このソフトウェアによってコンピューターに何らかの問題を起こした場合、雷さんや開発者は責任を取りません。
______________________________

## テクニカル情報

* Microsoft は SHA-1 の古い Windows Update エンドポイントを2020年8月に廃止しました。

* Windows Server 2008 の更新は、Windows Vista にもインストール可能です。

VistaUpdater によって、Windows Update クライアントのエンドポイントは自動的にSHA-2に移動されます。

* Windows Update は、VerifyVersionInfoWの関数を使用して、b.WindowsVersion の適用性ルールを認証します。

* kerneles.dll は偽の kernel32.dll で、VerifyVersionInfoW の関数のみを変更し、他の関数はすべて kernel32.dll に転送されます。

______________________________

## クレジット

* IMI Kurwica / kerneles.dll  
* M2-Team / NSudoLC.exe  
* abbodi1406 / プロジェクト
* 雷 / VistaUpdater
